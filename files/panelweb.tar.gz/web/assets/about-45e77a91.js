import{bg as t}from"./index-ef5b9a5d.js";function r(){return t({url:"/about"})}export{r as g};
