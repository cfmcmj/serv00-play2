import{bg as o}from"./index-ef5b9a5d.js";function n(r){return o({url:"/login",data:r})}function u(){return o({url:"/logout"})}export{u as a,n as l};
